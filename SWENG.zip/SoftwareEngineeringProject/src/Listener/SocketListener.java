package Listener;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.TimeUnit;

public class SocketListener {	
	public static void main(String[] args) throws IOException, InterruptedException, ClassNotFoundException {
	ServerSocket serverSocket = new ServerSocket(9090);
	Socket socket = serverSocket.accept();
	ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
	while(true) {
			if(inputStream.available() > 10)
			System.out.println(inputStream.readByte());
	}
	}
}
