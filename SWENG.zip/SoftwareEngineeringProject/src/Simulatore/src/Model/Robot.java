package Simulatore.src.Model;

public class Robot {
	private int idRobot;
	private int idCluster;
	private int idArea;
	private boolean[] segnali;
	
	public Robot(int idRobot, int idCluster, int idArea, boolean[] segnali) {
		this.idRobot = idRobot;
		this.idCluster = idCluster;
		this.idArea = idArea;
		this.segnali = segnali;
	}
	
	public int getIdRobot() {
		return idRobot;
	}
	
	public void setIdRobot(int idRobot) {
		this.idRobot = idRobot;
	}
	
	public int getIdCluster() {
		return idCluster;
	}
	
	public void setIdCluster(int idCluster) {
		this.idCluster = idCluster;
	}
	
	public int getIdArea() {
		return idArea;
	}
	
	public void setIdArea(int idArea) {
		this.idArea = idArea;
	}

	public boolean getSegnali(int indiceSegnale) {
		return segnali[indiceSegnale];
	}

	/*public void setSegnali(int indiceSegnale, int randomSegnale) {
		if(randomSegnale == 1) {
			randomSegnale = 0;
		}
		else {
			randomSegnale = 1;
		}
		this.segnali[indiceSegnale] = randomSegnale;
	} */
	
	public void setSegnale(int segnale) {
		segnali[segnale]= !segnali[segnale];
	}
	
}
