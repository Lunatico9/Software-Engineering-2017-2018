package Simulatore.src.Controller;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import Simulatore.src.Model.Robot;
import model.Signal;

public class Simulatore {
	private static final int numRobot = 90000;
	private static final int tipiSegnali = 7;
	private static final int numSegnaliMinuto = 90000;

	public static void main(String[] args) throws UnknownHostException, IOException, InterruptedException {
		ArrayList<Robot> robot = new ArrayList<Robot>();
		boolean[] segnali = new boolean[tipiSegnali];
		ArrayList<Signal> signals = new ArrayList<Signal>();
		// Popolo l'array "segnali" con tutti 1 (i robot sono inizialmente tutti up)
		for (int j = 0; j < tipiSegnali; j++) {
			segnali[j] = false;
		}
		// Popolo l'array "robot" di robot
		for (int i = 0; i < numRobot; i++) {
			robot.add(new Robot(i, i / 500, i / 5000, segnali));

		}
		/*
		 * Ogni sessanta secondi scorro tutti i robot dell'array "robot" scegliendone
		 * casualmente uno e generando per ciascuno un numero di segnali pari a
		 * "numSegnaliMin" scelti casualmente dall'array "segnali"
		 */
		for (int k = 0; k < numSegnaliMinuto; k++) {
			Robot r = robot.get((new Random()).nextInt(robot.size()));
			int indiceSegnale = new Random().nextInt(segnali.length);
			r.setSegnale(indiceSegnale);

			Signal s;
			if (!r.getSegnali(indiceSegnale)) {
				s = new Signal(r.getIdRobot(), r.getIdCluster(), r.getIdArea(), "up", System.currentTimeMillis() + k * 100);
			} else {
				s = new Signal(r.getIdRobot(), r.getIdCluster(), r.getIdArea(), "down", System.currentTimeMillis() + k * 100);
			}
			signals.add(s);
		}

		Socket socket = new Socket("127.0.0.1", 9090);
		System.out.println("Connection	established");
		ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
		try {
			for (int i = 0; i < numSegnaliMinuto; i++) {
				outputStream.writeObject(signals.get(i));
				outputStream.flush();
			}

		} catch (NoSuchElementException e) {
			System.out.println("Connection	closed");
		} finally {
			socket.close();
		}
	}

}
