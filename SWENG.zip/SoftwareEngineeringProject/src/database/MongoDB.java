package database;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.ServerAddress;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

import controller.*;
import model.Cluster;
import model.Robot;

import com.mongodb.MongoCredential;
import com.mongodb.MongoClientOptions;

import java.util.ArrayList;
import java.util.Arrays;

import org.bson.Document;
public class MongoDB {
	public static final int NUMERO_DOCUMENTI_IN_DB = 60;
	public static MongoClient mongoClient = new MongoClient("127.0.0.1" , 27017);
	public static MongoDatabase database = mongoClient.getDatabase("test");
	public static MongoCollection robotsDB = database.getCollection("robot");
	public static MongoCollection clustersDB = database.getCollection("clusters");
	
	public static void updateDBStatus (ArrayList<Robot> robots, ArrayList<Cluster> clusters) {
		SignalHandler.lastDocumentID += 1;
		Document robotStatus = new Document();
		for(int i = 0; i < robots.size(); i++) {
			robotStatus.append("robot", robots.get(i).getName())
						.append("uptime", robots.get(i).getUpTimeLocal());
		}
		Document doc = new Document("id",SignalHandler.lastDocumentID)
				.append("robots", robotStatus);
		robotsDB.insertOne(doc);
		
		Document clusterStatus = new Document();

		 for(int i = 0; i < clusters.size(); i++) {
			robotStatus.append("cluster", clusters.get(i).getName())
						.append("uptime", clusters.get(i).getUpTimeLocal());
		}
				doc = new Document("id",SignalHandler.lastDocumentID)
				.append("clusters", clusterStatus);
		clustersDB.insertOne(doc);
		
		//Documento 60 volte prima inserito da cancellare
				BasicDBObject firstDocument = new BasicDBObject();
				firstDocument.append("id", SignalHandler.lastDocumentID - NUMERO_DOCUMENTI_IN_DB);
				robotsDB.findOneAndDelete(firstDocument);
				clustersDB.findOneAndDelete(firstDocument);				
	}
	
	
	/*public static void main(String[] args) {
		long start = System.currentTimeMillis();
		BasicDBObject whereQuery = new BasicDBObject();
		whereQuery.put("name", 465);
		FindIterable cursor = robots.find();
		MongoCursor iterator = cursor.iterator();
		while(iterator.hasNext()) {
		 	Document a = (Document) iterator.next();
		 	String name = a.getString("name");
		 	if(name != null) {
		 	System.out.println(name);
		 	}
		}
		long end = System.currentTimeMillis();
		System.out.println(end - start);
	}
	*/
}
