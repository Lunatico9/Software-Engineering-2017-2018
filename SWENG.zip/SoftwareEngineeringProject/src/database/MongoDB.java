package database;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.ServerAddress;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

import model.Cluster;
import model.Robot;

import com.mongodb.MongoCredential;
import com.mongodb.MongoClientOptions;

import java.util.Arrays;

import org.bson.Document;
public class MongoDB {
	public static MongoClient mongoClient = new MongoClient("127.0.0.1" , 27017);
	public static MongoDatabase database = mongoClient.getDatabase("test");
	public static MongoCollection robots = database.getCollection("robot");
	public static MongoCollection clusters = database.getCollection("clusters");
	public static void insertRobot(Robot robot, String upDown) {
		Document doc = new Document("name", robot.getName())
				.append("time", System.currentTimeMillis())
				.append("status", upDown);
		robots.insertOne(doc);
	}
	public static void insertCluster(Cluster cluster, String upDown) {
		Document doc = new Document("name", cluster.getName())
				.append("time", System.currentTimeMillis())
				.append("status", upDown);
		clusters.insertOne(doc);
	}
	public static void main(String[] args) {
		long start = System.currentTimeMillis();
		BasicDBObject whereQuery = new BasicDBObject();
		whereQuery.put("name", 465);
		FindIterable cursor = robots.find();
		MongoCursor iterator = cursor.iterator();
		while(iterator.hasNext()) {
		 	Document a = (Document) iterator.next();
		 	String name = a.getString("name");
		 	if(name != null) {
		 	System.out.println(name);
		 	}
		}
		long end = System.currentTimeMillis();
		System.out.println(end - start);
	}
}
