import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import model.Area;
import model.Cluster;
import model.Robot;

public class Controller {

	public static void main(String[] args) {
		Robot[] robots = new Robot[90000];
		Cluster[] clusters = new Cluster[500];
		Area[] areas = new Area[300];
		long a =  System.currentTimeMillis();
		System.out.println(a);
		MongoClient mongoClient = new MongoClient("localhost" , 27017);
		MongoDatabase database = mongoClient.getDatabase("test");	
		MongoCollection<Document> collection = database.getCollection("robot");
		
		for (int i = 0; i < 90000; i++) {
			robots[i] = new Robot( i, i, System.currentTimeMillis(), i);
			List<Document> documents = new ArrayList<Document>();
			for (int j = 0; j < 10; j++) {
			Document document = new Document("title", "MongoDB") 
				      .append("id", i*100 + j)
				      .append("time",System.currentTimeMillis());
			documents.add(document);		       
			}
			collection.insertMany(documents);
			documents.clear();
		}
		System.out.println(System.currentTimeMillis()- a);
		mongoClient.close();

	}

}
