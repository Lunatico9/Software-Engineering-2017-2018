import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class SocketTry {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		int port = 9090;
		ServerSocket serverSocket = new ServerSocket(port);
		System.out.println("In attesa di segnali sulla porta " + port);
		Socket socket = serverSocket.accept();
		ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
		int count = 0;
		while(true) {
			try {
					ArrayList<String> signal =  (ArrayList<String>) inputStream.readObject();
					System.out.println(signal.get(1));	
					count++;
					System.out.println(count);
					}
			catch (Exception e2) {
				
			}		
		}
	}
}

