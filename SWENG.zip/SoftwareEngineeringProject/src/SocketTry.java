import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class SocketTry {
	public static void main(String[] args) throws IOException {
		int port = 4587;
		ServerSocket serverSocket = new ServerSocket(port);
		System.out.println("ServerSocket ready on port:" + port);
		//wait a connection
		Socket socket = serverSocket.accept();
		//Stream
		Scanner in = new Scanner(socket.getInputStream());
		PrintWriter out = new PrintWriter(socket.getOutputStream());
		
		//until quit
		
		while(true) {
			String line = in.nextLine();
			if(line.equals("quit")) {
			break;
		}else {
				out.println("Received" + line);
				out.flush();
			}
		}
		
		System.out.println("Closing Socket");
		in.close();
		out.close();
		socket.close();
		serverSocket.close();
	}
}
