package GUI.src.Model;

public class Cluster {
	
	String ID, ID_area, IR;
	int numRobot;
	
	public Cluster(String ID_C, String ID_A, int NR){
		this.ID= ID_C;
		this.ID_area=ID_A;
		this.numRobot=NR;
	}
	
	public String getID(){
		return this.ID;
	}
	
	public void setID(String iD){
		this.ID=iD;
	}
	
	public String getID_Area(){
		return this.ID_area;
	}
	
	public void setID_Area(String iD_A){
		this.ID_area=iD_A;
	}
	
	public int getnumRobot(){
		return this.numRobot;
	}
	
	public void setnumRobot(int nR){
		this.numRobot=nR;
	}
}
