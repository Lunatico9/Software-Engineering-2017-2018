package GUI.src.Model;

public class Robot {
	 private String ID, ID_Cluster, ID_Area;
	 private int IR;
	 
	 public Robot(String ID_R, String ID_C, String ID_A, int IRate){
		 this.setID(ID_R);
		 this.setID_Cluster(ID_C);
		 this.setID_Area(ID_A);
		 this.setIR(IRate);
	 }

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String getID_Cluster() {
		return ID_Cluster;
	}

	public void setID_Cluster(String iD_Cluster) {
		ID_Cluster = iD_Cluster;
	}

	public String getID_Area() {
		return ID_Area;
	}

	public void setID_Area(String iD_Area) {
		ID_Area = iD_Area;
	}

	public int getIR() {
		return IR;
	}

	public void setIR(int iR) {
		IR = iR;
	}
}
