package GUI.src.Model;

public class Area {
	
	private String ID;
	
	public Area(String ID_A){
		this.setID(ID_A);
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}
	
	
}
