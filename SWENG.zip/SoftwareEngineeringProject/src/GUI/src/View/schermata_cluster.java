package GUI.src.View;

import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import GUI.src.Controller.Controller;
import GUI.src.Model.Area;
import GUI.src.Model.Cluster;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class schermata_cluster extends schermata_aree{

	private JFrame frame;
	private JTable table;
	private String ID_Cluster="-1";
	private int NR;
	private Area B;
	private Cluster C;
	private JScrollPane scrollPane;
	
	/**
	 * Launch the application.
	 */
	public static void main(Area A) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					schermata_cluster window = new schermata_cluster(A);
					window.frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws Exception 
	 */
	public schermata_cluster(Area A) throws Exception {
		this.B=A;
		initialize();
	}
	
	public void show() throws Exception {
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		Object[] row = new Object[2];
		int j=0;
		for(int l=0; l<Cluster.size()-2; l++){
			if(Cluster.get(l+2).equals(B.getID()) && Cluster.get(l).substring(0,1).equals("C")){
				row[0] = Cluster.get(l);
				row[1] = Cluster.get(l+1);
				model.setRowCount(j);
				model.addRow(row);
				j++;
			}
		}
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws Exception 
	 */
	private void initialize() throws Exception {
		frame = new JFrame("Software Engineering");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		Timer timer= new Timer();
		TimerTask Task = new TimerTask(){
			public void run(){
				try {
					Controller.GeneraListe();
					show();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}	
		};
		timer.schedule(Task, 10000, 10000);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 246, 239);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable(){public boolean isCellEditable(int rowIndex, int mColIndex) {return false; }};
		scrollPane.setViewportView(table);
		table.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent ke) {
					    if(ke.getKeyCode() == KeyEvent.VK_DOWN || ke.getKeyCode() == KeyEvent.VK_UP)
					    {
					      ke.consume();
					    };
			}
		});
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				int a = table.getSelectedRow();
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				ID_Cluster=(String) model.getValueAt(a, 0);
			}
		});
		table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer(){
		    public Component getTableCellRendererComponent(JTable table,Object value, boolean isSelected, boolean hasFocus, int row, int col) {
		    	DefaultTableModel model = (DefaultTableModel) table.getModel();
				String IR= (String)model.getValueAt(row, 1);
				String S= IR.substring(0, IR.length()-1);
				int RateAttuale= Integer.parseInt(S);
		        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);
		        if (RateAttuale>=NumeroSogliaC){
		            setBackground(Color.red);
		        } 
		        else setBackground(Color.white);
		        if(RateAttuale==0){
		        	setBackground(Color.green);
		        }
		        
		        return this;
		    }   
		});

		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
			},
			new String[] {
				"ID_Cluster", "Inefficency Rate"
			}
		));
			
		JButton btnEntra = new JButton("Entra");
		btnEntra.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(!(ID_Cluster.equals("-1"))){
				C = new Cluster(ID_Cluster,B.getID(),NR);
				schermata_robot.main(B, C);
				frame.dispose();
				}
				else JOptionPane.showMessageDialog(null, "Seleziona un Cluster in cui entrare");
			}
		});
		btnEntra.setBounds(295, 50, 129, 23);
		frame.getContentPane().add(btnEntra);
		
		JButton btnIndietro = new JButton("Indietro");
		btnIndietro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				schermata_aree.main(null);
				frame.dispose();
			}
		});
		btnIndietro.setBounds(295, 14, 129, 23);
		frame.getContentPane().add(btnIndietro);
		
		JButton btnImpostaSoglia = new JButton("Imposta Soglia");
		btnImpostaSoglia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
				ImpostazioniCluster.main(B);
			}
		});
		btnImpostaSoglia.setBounds(295, 83, 129, 23);
		frame.getContentPane().add(btnImpostaSoglia);
		
		JLabel lblSogliaIrCluster = new JLabel("Soglia IR Cluster:");
		lblSogliaIrCluster.setBounds(266, 126, 104, 34);
		frame.getContentPane().add(lblSogliaIrCluster);
		
		JLabel lblSogliaIrRobot = new JLabel("Soglia IR Robot:");
		lblSogliaIrRobot.setBounds(266, 184, 104, 34);
		frame.getContentPane().add(lblSogliaIrRobot);
		
		JLabel LabelIRC = new JLabel("IRC");
		LabelIRC.setText(NumeroSogliaC+"%");
		LabelIRC.setBounds(380, 126, 44, 34);
		frame.getContentPane().add(LabelIRC);
		
		JLabel LabelIRR = new JLabel("IRR");
		LabelIRR.setText(NumeroSogliaR+"%");
		LabelIRR.setBounds(378, 184, 46, 34);
		frame.getContentPane().add(LabelIRR);
		
		show();
	}
}
