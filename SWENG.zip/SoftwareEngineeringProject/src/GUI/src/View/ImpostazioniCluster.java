package GUI.src.View;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import GUI.src.Model.Area;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ImpostazioniCluster{

	private JFrame frame;
	public JTextField textField;
	private JButton btnConferma;
	private Area B;

	/**
	 * Launch the application.
	 */
	public static void main(Area A) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ImpostazioniCluster window = new ImpostazioniCluster(A);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ImpostazioniCluster(Area A) {
		this.B=A;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(600, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblImpostaLaSoglia = new JLabel("Imposta la Soglia massima di Inefficency Rate");
		lblImpostaLaSoglia.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblImpostaLaSoglia.setHorizontalAlignment(SwingConstants.CENTER);
		lblImpostaLaSoglia.setBounds(10, 40, 414, 74);
		frame.getContentPane().add(lblImpostaLaSoglia);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setText("");
		textField.setBounds(85, 125, 275, 52);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		btnConferma = new JButton("Conferma");
		btnConferma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				schermata_cluster.NumeroSogliaC=Integer.parseInt(textField.getText());
				frame.dispose();
				schermata_cluster.main(B);
				}
		});
		btnConferma.setBounds(176, 188, 104, 30);
		frame.getContentPane().add(btnConferma);
	}

}
