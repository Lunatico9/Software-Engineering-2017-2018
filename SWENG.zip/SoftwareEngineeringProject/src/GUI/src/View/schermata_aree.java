package GUI.src.View;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import GUI.src.Model.Area;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

import GUI.src.Controller.Controller;

import javax.swing.JLabel;

public class schermata_aree {

	private JFrame frame;
	public static DefaultListModel<String> model;
	public static ArrayList<String> Aree, Cluster, Robot;
	public static int NUMA,NUMC,NUMR;
	public static int NumeroSogliaC=50,NumeroSogliaR=50;
	private JList<String> list;
	private JScrollPane scrollPane;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					schermata_aree window = new schermata_aree();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws IOException 
	 * @throws InterruptedException 
	 */
	public schermata_aree() throws IOException, InterruptedException {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws IOException 
	 * @throws InterruptedException 
	 */
	private void initialize() throws IOException, InterruptedException {
		frame = new JFrame("Software Engineering");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		Timer timer= new Timer();
		TimerTask Task = new TimerTask(){
			public void run(){
				try {
					Controller.GeneraListe();
					list = new JList<>(model);
					scrollPane.setViewportView(list);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}	
		};
		timer.schedule(Task, 10000, 10000);
			
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 216, 239);
		frame.getContentPane().add(scrollPane);
		
		Controller.GeneraListe();
		list = new JList<>(model);
		scrollPane.setViewportView(list);
		
		JButton btnEntra = new JButton("Entra");
		btnEntra.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(list.isSelectionEmpty()){
					JOptionPane.showMessageDialog(null, "Seleziona un Area in cui entrare");
				}
				else{
				Area A= new Area(list.getSelectedValue());
				//System.out.println(A.getID());
				schermata_cluster.main(A);
				frame.dispose();
				//System.out.println(Aree.toString());
				//System.out.println(Cluster.toString());
				//System.out.println(Robot.toString());
				}
			}
		});
		btnEntra.setBounds(236, 28, 188, 23);
		frame.getContentPane().add(btnEntra);
		
		JLabel lblSogliaIrCluster = new JLabel("Soglia IR Cluster:");
		lblSogliaIrCluster.setBounds(266, 126, 104, 34);
		frame.getContentPane().add(lblSogliaIrCluster);
		
		JLabel lblSogliaIrRobot = new JLabel("Soglia IR Robot:");
		lblSogliaIrRobot.setBounds(266, 184, 104, 34);
		frame.getContentPane().add(lblSogliaIrRobot);
		
		JLabel LabelIRC = new JLabel("IRC");
		LabelIRC.setText(NumeroSogliaC+"%");
		LabelIRC.setBounds(380, 126, 44, 34);
		frame.getContentPane().add(LabelIRC);
		
		JLabel LabelIRR = new JLabel("IRR");
		LabelIRR.setText(NumeroSogliaR+"%");
		LabelIRR.setBounds(378, 184, 46, 34);
		frame.getContentPane().add(LabelIRR);
		
		JButton btnImpostaSogliaCluster = new JButton("Imposta Soglia Cluster");
		btnImpostaSogliaCluster.setBounds(236, 65, 188, 23);
		frame.getContentPane().add(btnImpostaSogliaCluster);
		
		JButton button = new JButton("Imposta Soglia Robot");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		button.setBounds(236, 99, 188, 23);
		frame.getContentPane().add(button);
		
	}
}
