package GUI.src.View;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import GUI.src.Model.Area;
import GUI.src.Model.Cluster;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ImpostazioniRobot{

	private JFrame frame;
	public JTextField textField;
	private JButton btnConferma;
	private Cluster D;
	private Area B;

	/**
	 * Launch the application.
	 */
	public static void main(Area A,Cluster C) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ImpostazioniRobot window = new ImpostazioniRobot(A,C);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ImpostazioniRobot(Area A, Cluster C) {
		this.B=A;
		this.D=C;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(600, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblImpostaLaSoglia = new JLabel("Imposta la Soglia massima di Inefficency Rate");
		lblImpostaLaSoglia.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblImpostaLaSoglia.setHorizontalAlignment(SwingConstants.CENTER);
		lblImpostaLaSoglia.setBounds(10, 40, 414, 74);
		frame.getContentPane().add(lblImpostaLaSoglia);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 20));
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setText("");
		textField.setBounds(85, 125, 275, 52);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		btnConferma = new JButton("Conferma");
		btnConferma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				schermata_aree.NumeroSogliaR=Integer.parseInt(textField.getText());
				frame.dispose();
				schermata_robot.main(B,D);
				}
		});
		btnConferma.setBounds(176, 188, 104, 30);
		frame.getContentPane().add(btnConferma);
	}

}