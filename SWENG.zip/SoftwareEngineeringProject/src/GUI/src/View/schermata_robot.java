package GUI.src.View;

import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import GUI.src.Controller.Controller;
import GUI.src.Model.Area;
import GUI.src.Model.Cluster;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class schermata_robot extends schermata_aree{

	private JFrame frame;
	private JTable table1;
	private Area A;
	private Cluster C;
	private JScrollPane scrollPane;
	String ID_Robot;

	/**
	 * Launch the application.
	 */
	public static void main(Area B, Cluster D) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					schermata_robot window = new schermata_robot(B,D);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public schermata_robot(Area B, Cluster D) throws Exception {
		this.A=B;
		this.C=D;
		initialize();
	}
	
	public void showR() throws Exception {
		DefaultTableModel model = (DefaultTableModel) table1.getModel();
		Object[] row = new Object[2];
		int j=0;
		for(int l=0; l<Robot.size()-3; l++){
			if(Robot.get(l).substring(0,1).equals("R") && Robot.get(l+2).equals(C.getID()) && Robot.get(l+3).equals(A.getID())){
				row[0] = Robot.get(l);
				row[1] = Robot.get(l+1);
				model.setRowCount(j);
				model.addRow(row);
				j++;
			}
		}
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws Exception 
	 */
	private void initialize() throws Exception {
		frame = new JFrame("Software Engineering");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		Timer timer= new Timer();
		TimerTask Task = new TimerTask(){
			public void run(){
				try {
					Controller.GeneraListe();
					showR();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}	
		};
		timer.schedule(Task, 10000, 10000);
		
		JButton btnEntra = new JButton("Indietro");
		btnEntra.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				schermata_cluster.main(A);
				frame.dispose();
			}
		});
		btnEntra.setBounds(295, 14, 129, 23);
		frame.getContentPane().add(btnEntra);
		
		JButton btnImpostazioni = new JButton("Imposta Soglia");
		btnImpostazioni.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			ImpostazioniRobot.main(A, C);
			frame.dispose();
			}
		});
		btnImpostazioni.setBounds(295, 49, 129, 23);
		frame.getContentPane().add(btnImpostazioni);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 246, 239);
		frame.getContentPane().add(scrollPane);
		
		table1 = new JTable(){public boolean isCellEditable(int rowIndex, int mColIndex) {return false; }};
		scrollPane.setViewportView(table1);
		table1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent ke) {
					    if(ke.getKeyCode() == KeyEvent.VK_DOWN || ke.getKeyCode() == KeyEvent.VK_UP)
					    {
					      ke.consume();
					    };
			}
		});
		table1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table1.addMouseListener(new MouseAdapter() {

			public void mouseClicked(MouseEvent e) {
				int a = table1.getSelectedRow();
				DefaultTableModel model = (DefaultTableModel) table1.getModel();
				ID_Robot= (String) model.getValueAt(a, 0);
			}
		});
		table1.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
				{null, null},
			},
			new String[] {
				"ID_Robot", "Inefficency Rate"
			}
		));
		table1.setDefaultRenderer(Object.class, new DefaultTableCellRenderer(){
		    public Component getTableCellRendererComponent(JTable table,Object value, boolean isSelected, boolean hasFocus, int row, int col) {
		    	DefaultTableModel model = (DefaultTableModel) table.getModel();
				String IR= (String)model.getValueAt(row, 1);
				String S= IR.substring(0, IR.length()-1);
				int RateAttuale= Integer.parseInt(S);
		        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);
		        if (RateAttuale>=NumeroSogliaR){
		            setBackground(Color.red);
		        } 
		        else setBackground(Color.white);
		        if(RateAttuale==0){
		        	setBackground(Color.green);
		        }
		        
		        return this;
		    }   
		});
		
		JLabel lblSogliaIrCluster = new JLabel("Soglia IR Cluster:");
		lblSogliaIrCluster.setBounds(266, 126, 104, 34);
		frame.getContentPane().add(lblSogliaIrCluster);
		
		JLabel lblSogliaIrRobot = new JLabel("Soglia IR Robot:");
		lblSogliaIrRobot.setBounds(266, 184, 104, 34);
		frame.getContentPane().add(lblSogliaIrRobot);
		
		JLabel LabelIRC = new JLabel("IRC");
		LabelIRC.setText(NumeroSogliaC+"%");
		LabelIRC.setBounds(380, 126, 44, 34);
		frame.getContentPane().add(LabelIRC);
		
		JLabel LabelIRR = new JLabel("IRR");
		LabelIRR.setText(NumeroSogliaR+"%");
		LabelIRR.setBounds(378, 184, 46, 34);
		frame.getContentPane().add(LabelIRR);
		
		showR();
	}
}
