package GUI.src.Controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.DefaultListModel;

import GUI.src.Model.Area;
import GUI.src.View.schermata_aree;

public class Controller {
	
	
	public static void GeneraListe() throws IOException{
		String Area,Clusters,Robots;
		FileReader f=new FileReader ("src/IR.txt");
		BufferedReader b=new BufferedReader(f);
		schermata_aree.model= new DefaultListModel<>();
		
		ArrayList<String> AA= new ArrayList<String>();
		ArrayList<String> AC = new ArrayList<String>();
		ArrayList<String> AR = new ArrayList<String>();
		
		String NumeroAree= b.readLine(); //Leggo numero aree
		schermata_aree.NUMA= Integer.parseInt(NumeroAree); //Trasformo in Int numero aree
		
		String NumeroCluster=b.readLine(); //Leggo numero Cluster
		schermata_aree.NUMC= Integer.parseInt(NumeroCluster); //Trasformo in int Numero Cluster
		
		String NumeroRobot=b.readLine(); //Leggo numero Robot
		schermata_aree.NUMR= Integer.parseInt(NumeroRobot); //trasformo in int numero robot

		int a=0; //Posizione per aggiungere elementi nell'ArrayList delle Aree
		
		for(int i=0; i<(schermata_aree.NUMA*2+schermata_aree.NUMC*3+schermata_aree.NUMR*2); i++){ //fa scorrere tutte le righe del file
			Area=b.readLine();
			if(Area==null){
				break;
			}
			if(Area.substring(0, 1).equals("A")){
				AA.add(a,Area);
				a++;
				String S= Area;
				Area A= new Area (S);
				schermata_aree.model.addElement(A.getID());
				String NClus= b.readLine();
				int NCluster= Integer.parseInt(NClus);
				for(int j=0; j<(NCluster); j++){
					String Clus=b.readLine();
						if(Clus.substring(0, 1).equals("C")){
							String IRC= b.readLine();
							int IrateC= Integer.parseInt(IRC);
							Clusters=Clus;
							AC.add(Clusters);
							Clusters=IrateC+"%";
							AC.add(Clusters);
							Clusters=Area;
							AC.add(Clusters);
							String NRob= b.readLine();
							int Nrobot= Integer.parseInt(NRob);
							for(int q=0; q<(Nrobot); q++){
								String Robo= b.readLine();
								if(Robo.substring(0, 1).equals("R")){
									String IRR= b.readLine();
									int IrateR = Integer.parseInt(IRR);
									Robots=Robo;
									AR.add(Robots);
									Robots=IrateR+"%";
									AR.add(Robots);
									Robots=Clus;
									AR.add(Robots);
									Robots=Area;
									AR.add(Robots);
								}
							}
						}
					}
				}
			}
			schermata_aree.Aree=AA;
			schermata_aree.Cluster=AC;
			schermata_aree.Robot=AR;
	}

}
