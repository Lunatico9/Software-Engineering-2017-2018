package model;

public class Area {
	private int name;
	
	public Area(int name) {
		this.setName(name);
	}

	public int getName() {
		return name;
	}

	public void setName(int name) {
		this.name = name;
	}
}
