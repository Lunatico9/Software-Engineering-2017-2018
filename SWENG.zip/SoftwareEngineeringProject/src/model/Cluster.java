package model;

import java.util.Date;

public class Cluster {
	private int name;
	private int downRobot;
	private long lastChange;
	private int areaID;
	private int lastEfficiency = 100;
	
	public Cluster(int name, int downRobot, long lastChange, int areaID){
		this.name = name;
		this.setDownRobot(downRobot);
		this.lastChange = lastChange;
		this.setAreaID(areaID);
	}
	public int getName() {
		return name;
	}
	public void setName(int name) {
		this.name = name;
	}
	public long getLastChange() {
		return lastChange;
	}
	public void setLastChange(long lastChange) {
		this.lastChange = lastChange;
	}
	public int getDownRobot() {
		return downRobot;
	}
	public void setDownRobot(int downRobot) {
		this.downRobot = downRobot;
	}
	public int getLastEfficiency() {
		return lastEfficiency;
	}
	public void setLastEfficiency(int lastEfficiency) {
		this.lastEfficiency = lastEfficiency;
	}
	public int getAreaID() {
		return areaID;
	}
	public void setAreaID(int areaID) {
		this.areaID = areaID;
	}
}
