package model;

public class Robot {
	private int name;
	private int downSignals;
	private long lastChange;
	private int clusterID;
	private int lastEfficiency = 100;
	
	public Robot(int name, int downSignals, long lastChange, int clusterID){
		this.name = name;
		this.downSignals = downSignals;
		this.lastChange = lastChange;
		this.clusterID = clusterID;
		
	}
	public long getLastChange() {
		return lastChange;
	}
	public void setLastChange(long lastChange) {
		this.lastChange = lastChange;
	}
	public int getDownSignals() {
		return downSignals;
	}
	public void setDownSignals(int downSignals) {
		this.downSignals = downSignals;
	}
	public int getName() {
		return name;
	}
	public void setName(int name) {
		this.name = name;
	}
	public int getClusterID() {
		return clusterID;
	}
	public void setClusterID(int clusterID) {
		this.clusterID = clusterID;
	}
	public int getLastEfficiency() {
		return lastEfficiency;
	}
	public void setLastEfficiency(int lastEfficiency) {
		this.lastEfficiency = lastEfficiency;
	}
}
