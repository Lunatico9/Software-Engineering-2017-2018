import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.ChannelPromise;
import io.netty.util.ReferenceCountUtil;

public class DiscardServerHandler extends ChannelInboundHandlerAdapter {
//    private MemQueue mem;
//    private Thread t;
	  static int a = 0;
	  static long l = System.currentTimeMillis();
//    public DiscardServerHandler() {
//        super();
//        System.out.println("called once");
//        mem = new MemQueue(new LinkedBlockingQueue<byte[]>());
//        t = new Thread(mem);
//        t.start();
//    }
    
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) {
        ByteBuf in = (ByteBuf) msg;
        try {
            //System.out.println("<read start>");
            //System.out.print(in.toString(io.netty.util.CharsetUtil.US_ASCII));
           while (in.isReadable()) {
            System.out.print((char) in.readByte());
            }
            //System.out.println(System.currentTimeMillis() - l);
            //System.out.println("<read end>");
        } finally {
            //System.out.flush();
            ReferenceCountUtil.release(msg);
        }
    }
    
    @Override
    public void exceptionCaught(ChannelHandlerContext arg0, Throwable arg1) throws Exception {
        // TODO Auto-generated method stub

    }

    @Override
    public void handlerAdded(ChannelHandlerContext arg0) throws Exception {
        // TODO Auto-generated method stub

    }

    @Override
    public void handlerRemoved(ChannelHandlerContext arg0) throws Exception {
        // TODO Auto-generated method stub

    }

}
