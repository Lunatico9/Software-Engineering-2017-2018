import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import model.Signal;

public class SocketClientTry {
	public static void main(String[] args) throws UnknownHostException, IOException, InterruptedException {
		Socket	socket	= new Socket("127.0.0.1" , 9090); 	
		System.out.println("Connection	established");
		ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());									
		try { 	
			for(Integer i = 0; i < 90000;  i++) {
			Signal signal = new Signal(i, 1, i, "down", i);
			outputStream.writeObject(signal);
            outputStream.flush();
			}

			} catch(NoSuchElementException e) {
				System.out.println("Connection	closed"); 		
				} finally { 					
						socket.close();
	}
}
}
