import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class SocketClientTry {
	public static void main(String[] args) throws UnknownHostException, IOException, InterruptedException {
		Socket	socket	= new Socket("127.0.0.1" , 9090); 	
		System.out.println("Connection	established");
		Scanner	socketIn = new	Scanner(socket.getInputStream());
		ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
		PrintWriter socketOut = new PrintWriter(outputStream);
		Scanner	stdin = new	Scanner(System.in); 									
		try { 	
			int i = 0;
			String[] names = new String[1];
			names[0] = "ciao"; 
			//outputStream.writeObject(names); 
			outputStream.write(names[0].getBytes("UTF-8"));
            outputStream.flush();
			} catch(NoSuchElementException e) {
				System.out.println("Connection	closed"); 		
				} finally { 					
					stdin.close();
						socketIn.close(); 	
						socketOut.close();
						socket.close();
	}
}
}
