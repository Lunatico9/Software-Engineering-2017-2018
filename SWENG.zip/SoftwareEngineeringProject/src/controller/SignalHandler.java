package controller;

import database.MongoDB;
import model.Cluster;
import model.Robot;
import model.Signal;

public class SignalHandler {
	public static void signalHandler(Signal s) {
		//Cerco robot (Gestire se non esiste)
		Robot robot = Main.robots.get(s.getIdRobot());
		Cluster cluster = Main.clusters.get(s.getIdCluster());
		//Controllo se robot esiste
		if (cluster == null) {
			Main.clusters.set(s.getIdCluster(), new Cluster(s.getIdCluster(), 0, System.currentTimeMillis(), s.getIdArea()));
			cluster = Main.clusters.get(s.getIdCluster());
			if (robot == null) {
			Main.robots.set(s.getIdRobot(), new Robot(s.getIdRobot(), 0, System.currentTimeMillis(), s.getIdCluster()));
			robot = Main.robots.get(s.getIdRobot());
			}
		}
		//Aggiorno Valore robot
	if(s.getUpDown().equals("down")){
				robot.setDownSignals(robot.getDownSignals() + 1);
				if(robot.getDownSignals() == 1) {
					//Aggiorna database ed efficienza e lastChange
					robot.setLastEfficiency((int) (robot.getLastEfficiency() + System.currentTimeMillis() - robot.getLastChange()));
					robot.setLastChange(System.currentTimeMillis());
					MongoDB.insertRobot(robot, "down");
					//Aggiorno eventualmente Cluster
					cluster.setDownRobot(cluster.getDownRobot() + 1);
					if(cluster.getDownRobot() == 1) {
						//Aggiorno Cluster
						cluster.setLastEfficiency((int) (robot.getLastEfficiency() + System.currentTimeMillis() - robot.getLastChange()));
						cluster.setLastChange(System.currentTimeMillis());
						MongoDB.insertCluster(cluster, "down");
					}
				}
		}
				else {
				robot.setDownSignals(robot.getDownSignals() - 1);
				if(robot.getDownSignals() == 0) {
					//Aggiorna database e lastChange
					robot.setLastChange(System.currentTimeMillis());
					MongoDB.insertRobot(robot, "up");
					//Aggiorno eventualmente Cluster
					cluster.setDownRobot(cluster.getDownRobot() - 1);
					if(cluster.getDownRobot() == 0) {
						//Aggiorno Cluster
						cluster.setLastChange(System.currentTimeMillis());
						MongoDB.insertCluster(cluster, "up");
					}
				}
				}
		}
	}
