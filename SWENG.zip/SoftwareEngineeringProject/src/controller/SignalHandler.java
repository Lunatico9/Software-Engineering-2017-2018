package controller;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import database.MongoDB;
import model.Area;
import model.Cluster;
import model.Robot;
import model.Signal;

public class SignalHandler {
	static public List<Robot> robots = new ArrayList<Robot>();
	static public List<Cluster> clusters = new ArrayList<Cluster>();
	static public List<Area> areas = new ArrayList<Area>();
	static public int lastDocumentID = 0;
	static final long REFRESH_RATE = 10000; // in milliseconds

	public static void signalHandler(Signal s) {
		// Cerco robot (Gestire se non esiste)
		Robot robot = robots.get(s.getIdRobot());
		Cluster cluster = clusters.get(s.getIdCluster());
		// Controllo se robot esiste
		if (cluster == null) {
			clusters.set(s.getIdCluster(), new Cluster(s.getIdCluster(), 0, s.getMilliSeconds(), s.getIdArea()));
			cluster = clusters.get(s.getIdCluster());
			if (robot == null) {
				robots.set(s.getIdRobot(), new Robot(s.getIdRobot(), 0, s.getMilliSeconds(), s.getIdCluster()));
				robot = robots.get(s.getIdRobot());
			}
		}
		// fixo i bug brutti
		if (robot.getLastChange() == 0)
			robot.setLastChange(s.getMilliSeconds());
		// Aggiorno Valore robot
		if (s.getUpDown().equals("down")) {
			robot.setDownSignals(robot.getDownSignals() + 1);
			if (robot.getDownSignals() == 1) {
				// Aggiorna database ed efficienza e lastChange
				robot.setUpTimeLocal(robot.getUpTimeLocal() + (s.getMilliSeconds() - robot.getLastChange()));
				robot.setUpTimeTotal(robot.getUpTimeTotal() + s.getMilliSeconds() - robot.getLastChange());
				robot.setLastChange(s.getMilliSeconds());
				// Aggiorno eventualmente Cluster
				cluster.setDownRobot(cluster.getDownRobot() + 1);
				if (cluster.getDownRobot() == 1) {
					// Aggiorno Cluster
					cluster.setUpTimeLocal(cluster.getUpTimeLocal() + (s.getMilliSeconds() - cluster.getLastChange()));
					cluster.setUpTimeTotal((robot.getUpTimeTotal() + s.getMilliSeconds() - robot.getLastChange()));
					cluster.setLastChange(s.getMilliSeconds());
				}
			}
		} else {
			robot.setDownSignals(robot.getDownSignals() - 1);
			if (robot.getDownSignals() == 0) {
				// Aggiorna database e lastChange
				robot.setLastChange(s.getMilliSeconds());
				// Aggiorno eventualmente Cluster
				cluster.setDownRobot(cluster.getDownRobot() - 1);
				if (cluster.getDownRobot() == 0) {
					// Aggiorno Cluster
					cluster.setLastChange(s.getMilliSeconds());
				}
			}
		}
	}

	public static void updateUpTime() {
		long current = System.currentTimeMillis();
		for (int i = 0; i < robots.size(); i++) {
			Robot robot = robots.get(i);
			if (robot.getDownSignals() == 0) { // Se il robot � up
				long timeDiff = current - robot.getLastChange();
				robot.setLastChange(current);
				robot.setUpTimeLocal(robot.getUpTimeLocal() + timeDiff);
				robot.setUpTimeTotal(robot.getUpTimeTotal() + timeDiff);
			}
		}
		for (int i = 0; i < clusters.size(); i++) {
			Cluster cluster = clusters.get(i);
			if (cluster.getDownRobot() == 0) { // Se il robot � up
				long timeDiff = current - cluster.getLastChange();
				cluster.setLastChange(current);
				cluster.setUpTimeLocal(cluster.getUpTimeLocal() + timeDiff);
				cluster.setUpTimeTotal(cluster.getUpTimeTotal() + timeDiff);
			}
		}
	}

	public static void main(String[] args) throws IOException {
		int port = 9090;
		ServerSocket serverSocket = new ServerSocket(port);
		System.out.println("In attesa di segnali sulla porta " + port);
		Socket socket = serverSocket.accept();
		ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
		for (int i = 0; i < 90000; i++) {
			robots.add(new Robot(i, 0, 0, i / 500));
		}
		for (int i = 0; i < 180; i++) {
			clusters.add(new Cluster(i, 0, 0, i / 10));
		}
		for (int i = 0; i < 18; i++) {
			areas.add(new Area(i));
		}
		long time = System.currentTimeMillis();
		while (true) {
			Signal signal;
			try {
				signal = (Signal) inputStream.readObject();
				signalHandler(signal);
			} catch (ClassNotFoundException e) {
			} catch (IOException e) {
			}

			long currentTime = System.currentTimeMillis();
			if (currentTime > time + REFRESH_RATE) {
				time = currentTime;
				// updateUpTime();

				// Chiama ViewBuilder
				ViewBuilder.updateFile();
				System.out.println("prova");
				// Chiama Database
			}
		}
	}
}
