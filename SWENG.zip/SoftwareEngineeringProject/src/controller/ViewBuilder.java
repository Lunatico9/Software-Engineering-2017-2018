package controller;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import model.Area;
import model.Cluster;
import model.Robot;

public class ViewBuilder {
	public static void updateFile() throws FileNotFoundException, UnsupportedEncodingException {
		PrintWriter writer = new PrintWriter("src/IR.txt", "UTF-8");
		writer.println(SignalHandler.areas.size());
		writer.println(SignalHandler.clusters.size());
		writer.println(SignalHandler.robots.size());
		for(Area a: SignalHandler.areas) {
			writer.println("A"+ a.getName());
			//TEST
			writer.println("10");
			for(Cluster c: SignalHandler.clusters) {
				if(c.getAreaID() == a.getName()) {
				writer.println("C"+ c.getName());
				writer.println(100-(c.getUpTimeTotal()/3600000)*100);
				//TEST
				writer.println("500");
				}
				for(Robot r: SignalHandler.robots) {
					if(r.getClusterID() == c.getName() && c.getAreaID() == a.getName()) {
					writer.println("R"+ r.getName());
					writer.println(100-(r.getUpTimeTotal()/3600000)*100);
						if(r.getUpTimeTotal() > 360000)
						System.out.println(((float)r.getUpTimeTotal()/3600000)*100);
					}
				}
			}
		}
		writer.close();
		System.out.println("Finito");
	}
}
