package controller;

import java.util.List;

import model.Area;
import model.Cluster;
import model.Robot;

public class Main {
	static public List<Robot>robots;
	static public List<Cluster>clusters;
	static public List<Area>areas;
	
	public static void main(String[] args) {
		
	}
}
